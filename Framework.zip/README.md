Installations Required:
Java latest - Environment variables must
Maven
TestNg

//After installation done
Maven clean the project
Maven update the project

//Execution
right click on "testngSWAGlabs" and run as testNg
before execution please make sure environment setup is done

//Executing in different browser
in testNg xml file update browser name parameter

