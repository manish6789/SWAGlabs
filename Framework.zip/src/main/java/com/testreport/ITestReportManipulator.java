package com.testreport;


public interface ITestReportManipulator {

	 void Manipulate();
}
